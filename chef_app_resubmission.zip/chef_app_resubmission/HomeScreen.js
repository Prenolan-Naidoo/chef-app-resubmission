// HomeScreen.js
// Displays menu items and average prices
// Enhancements by Prenolan Naidoo

import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { useMenu } from './menucontext';

const HomeScreen = ({ navigation }) => {
  const { menu } = useMenu();

  const calculateAverage = () => {
    if (menu.length === 0) return 0;
    const total = menu.reduce((sum, item) => sum + item.price, 0);
    return (total / menu.length).toFixed(2);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Christoffel's Menu</Text>
      <Text style={styles.subtitle}>Explore our exclusive dishes curated for the finest tastes.</Text>
      <Text style={styles.average}>Average Price: R{calculateAverage()}</Text>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemDetails}>R{item.price} ({item.course})</Text>
          </View>
        )}
      />

      <View style={styles.buttonGroup}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Manage Menu')}
        >
          <Text style={styles.buttonText}>Manage Menu</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Filter Menu')}
        >
          <Text style={styles.buttonText}>Filter Menu</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => navigation.navigate('Add Menu Item')}
        >
          <Text style={styles.buttonText}>Add Menu Item</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#121212' },
  heading: { fontSize: 30, fontWeight: 'bold', color: '#f8c12d', textAlign: 'center', marginBottom: 10 },
  subtitle: { fontSize: 18, color: '#f8f8f8', textAlign: 'center', marginBottom: 20 },
  average: { fontSize: 20, fontWeight: '700', color: '#ffffff', marginBottom: 20 },
  itemContainer: {
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#2c2c2c',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  itemName: { fontSize: 18, fontWeight: 'bold', color: '#f8c12d' },
  itemDetails: { fontSize: 16, color: '#e0e0e0' },
  buttonGroup: { marginTop: 20 },
  button: {
    backgroundColor: '#f8c12d',
    paddingVertical: 12,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: { color: '#1e1e1e', fontSize: 18, fontWeight: '700' },
});

export default HomeScreen;
