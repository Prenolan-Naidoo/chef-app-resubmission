// AddMenuItemScreen.js
// Add new menu items
// Enhancements by Prenolan Naidoo

import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { useMenu } from './menucontext';

const AddMenuItemScreen = () => {
  const { addMenuItem } = useMenu();
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState('');

  const handleAddItem = () => {
    if (!name || !price || !course) return;
    const newItem = {
      id: Date.now().toString(),
      name,
      price: parseFloat(price),
      course,
    };
    addMenuItem(newItem);
    setName('');
    setPrice('');
    setCourse('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Add a New Dish</Text>

      <TextInput
        style={styles.input}
        placeholder="Dish Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Price (R)"
        value={price}
        onChangeText={setPrice}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Course (Starter, Main, Dessert)"
        value={course}
        onChangeText={setCourse}
      />

      <TouchableOpacity style={styles.addButton} onPress={handleAddItem}>
        <Text style={styles.addButtonText}>Add Dish</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#121212' },
  heading: { fontSize: 28, fontWeight: 'bold', color: '#f8c12d', textAlign: 'center', marginBottom: 20 },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 10,
    marginVertical: 10,
    borderRadius: 5,
    backgroundColor: '#ffffff',
  },
  addButton: {
    backgroundColor: '#f8c12d',
    paddingVertical: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  addButtonText: { color: '#1e1e1e', fontSize: 18, fontWeight: '700' },
});

export default AddMenuItemScreen;
