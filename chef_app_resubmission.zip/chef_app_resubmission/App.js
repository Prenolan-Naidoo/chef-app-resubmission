// App.js
// Main application entry point
// Enhancements by Prenolan Naidoo

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { MenuProvider } from './menucontext';
import HomeScreen from './HomeScreen';
import ManageMenuScreen from './ManageMenuScreen';
import AddMenuItemScreen from './AddMenuItemScreen';
import FilterMenuScreen from './FilterMenuScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <MenuProvider>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="Home"
          screenOptions={{
            headerStyle: { backgroundColor: '#1e1e1e' },
            headerTintColor: '#f8c12d',
            headerTitleStyle: { fontWeight: '700', fontSize: 24, color: '#ffffff' },
          }}
        >
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Manage Menu" component={ManageMenuScreen} />
          <Stack.Screen name="Add Menu Item" component={AddMenuItemScreen} />
          <Stack.Screen name="Filter Menu" component={FilterMenuScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </MenuProvider>
  );
};

export default App;
