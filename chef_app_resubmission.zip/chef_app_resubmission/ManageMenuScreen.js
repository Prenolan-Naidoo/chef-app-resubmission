// ManageMenuScreen.js
// Manage and remove menu items
// Enhancements by Prenolan Naidoo

import React from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { useMenu } from './menucontext';

const ManageMenuScreen = () => {
  const { menu, removeMenuItem } = useMenu();

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Manage Menu</Text>

      <FlatList
        data={menu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <View style={styles.itemDetailsContainer}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemPrice}>R{item.price}</Text>
              <Text style={styles.itemCourse}>({item.course})</Text>
            </View>
            <TouchableOpacity
              style={styles.removeButton}
              onPress={() => removeMenuItem(item.id)}
            >
              <Text style={styles.removeButtonText}>Remove</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#121212' },
  heading: { fontSize: 28, fontWeight: 'bold', color: '#f8c12d', textAlign: 'center', marginBottom: 20 },
  itemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#2c2c2c',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  itemDetailsContainer: { flex: 1 },
  itemName: { fontSize: 18, fontWeight: 'bold', color: '#f8c12d' },
  itemPrice: { fontSize: 16, color: '#e0e0e0', marginTop: 5 },
  itemCourse: { fontSize: 16, color: '#e0e0e0', marginTop: 5 },
  removeButton: {
    backgroundColor: '#d32f2f',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
    alignSelf: 'center',
  },
  removeButtonText: { color: '#ffffff', fontWeight: '600', fontSize: 16 },
});

export default ManageMenuScreen;
