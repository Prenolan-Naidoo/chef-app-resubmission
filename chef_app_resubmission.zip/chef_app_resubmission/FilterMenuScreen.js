// FilterMenuScreen.js
// Filter menu items by course
// Enhancements by Prenolan Naidoo

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { useMenu } from './menucontext';

const FilterMenuScreen = () => {
  const { menu } = useMenu();
  const [filter, setFilter] = useState('');

  const filteredMenu = filter ? menu.filter((item) => item.course === filter) : menu;

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Filter Menu</Text>
      <Text style={styles.subtitle}>Select a category to view specific dishes</Text>

      <View style={styles.buttonGroup}>
        <TouchableOpacity style={styles.filterButton} onPress={() => setFilter('')}>
          <Text style={styles.filterButtonText}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.filterButton} onPress={() => setFilter('Starter')}>
          <Text style={styles.filterButtonText}>Starters</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.filterButton} onPress={() => setFilter('Main')}>
          <Text style={styles.filterButtonText}>Mains</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.filterButton} onPress={() => setFilter('Dessert')}>
          <Text style={styles.filterButtonText}>Desserts</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredMenu}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemDetails}>R{item.price} ({item.course})</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#121212' },
  heading: { fontSize: 28, fontWeight: 'bold', color: '#f8c12d', textAlign: 'center', marginBottom: 10 },
  subtitle: { fontSize: 18, color: '#f8f8f8', textAlign: 'center', marginBottom: 20 },
  buttonGroup: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  filterButton: {
    backgroundColor: '#f8c12d',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  filterButtonText: { color: '#1e1e1e', fontWeight: '700', fontSize: 16 },
  itemContainer: {
    padding: 15,
    borderRadius: 10,
    backgroundColor: '#2c2c2c',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
  },
  itemName: { fontSize: 18, fontWeight: 'bold', color: '#f8c12d' },
  itemDetails: { fontSize: 16, color: '#e0e0e0' },
});

export default FilterMenuScreen;
