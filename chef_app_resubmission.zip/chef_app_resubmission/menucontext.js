// menucontext.js
// Context for managing menu state
// Enhancements by Prenolan Naidoo

import React, { createContext, useContext, useState } from 'react';

const MenuContext = createContext();

export const MenuProvider = ({ children }) => {
  const [menu, setMenu] = useState([]); // Array to store menu items

  const addMenuItem = (item) => {
    setMenu((prevMenu) => [...prevMenu, item]); // Append new item
  };

  const removeMenuItem = (id) => {
    setMenu((prevMenu) => prevMenu.filter((item) => item.id !== id)); // Remove by ID
  };

  return (
    <MenuContext.Provider value={{ menu, addMenuItem, removeMenuItem }}>
      {children}
    </MenuContext.Provider>
  );
};

export const useMenu = () => {
  const context = useContext(MenuContext);
  if (!context) {
    throw new Error('useMenu must be used within a MenuProvider');
  }
  return context;
};
